# Bulk Cek Rekening — Lookup & Validate (Node.js + Web UI)

Dua opsi sekaligus:
1) **Cek Masal (lookup)**: dari CSV `bank,account_number` ➜ hasil nama pemilik & status dari API, bisa di‑download CSV.
2) **Validasi Nama**: dari CSV `bank,account_number,name` ➜ cek API lalu validasi apakah **nama sama** (exact match). Skor `similarity` ikut disertakan.

## Cara jalanin
```bash
cp .env.example .env
# isi ATLANTIC_API_KEY=...

npm install
npm start
```
Buka:
- UI: `http://localhost:3000/ui`
- Health: `http://localhost:3000/health`
- Template CSV: `GET /template?mode=lookup` atau `mode=validate`

## Endpoint
- `POST /bulk-lookup?format=json|csv`  (form-data: `file=<CSV>`)
- `POST /bulk-validate?format=json|csv` (form-data: `file=<CSV>`)

## Format CSV
- **Lookup**: kolom minimal `bank,account_number`
- **Validate**: kolom minimal `bank,account_number,name`

Alias kolom yang didukung: `bank_name`, `nama bank`, `norek`, `no rekening`, `nomor rekening`, `nama`, `nama orang`, `nama lengkap`.

## Output
- Lookup CSV columns: `bank, bank_code, account_number, api_name, api_status, note`
- Validate CSV columns: `bank, bank_code, account_number, expected_name, api_name, api_status, valid_exact, similarity, note`

## Konfigurasi
- `.env`:
```
ATLANTIC_API_KEY=...
PORT=3000
ALLOW_ORIGIN=*         # ubah ke domain kamu untuk produksi
RATE_DELAY_MS=200      # jeda antar request (ms)
TIMEOUT_MS=15000       # timeout upstream (ms)
```
- `BANK_CODE_MAP` di `server.js` bisa kamu tambahkan sesuai daftar bank Atlantic Pedia.

## Catatan
- API upstream: `https://atlantich2h.com/transfer/cek_rekening` (metode POST, form-urlencoded).
- Server ini menghindari CORS & menyembunyikan API key dari frontend.
- Default rate-limit halus (delay 200 ms) supaya tidak membanjiri upstream.
