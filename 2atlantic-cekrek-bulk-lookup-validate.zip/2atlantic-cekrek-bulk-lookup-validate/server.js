// Bulk lookup/validate Atlantic Pedia "cek rekening" with CSV upload
import express from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";
import Papa from "papaparse";
dotenv.config();

let fetchFn = globalThis.fetch;
if (!fetchFn) {
  const mod = await import("node-fetch");
  fetchFn = mod.default;
}

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ATLANTIC_API_KEY;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || "*";
const RATE_DELAY_MS = parseInt(process.env.RATE_DELAY_MS || "200", 10);
const TIMEOUT_MS = parseInt(process.env.TIMEOUT_MS || "15000", 10);

app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: ALLOW_ORIGIN }));

// ---- Helpers ----
const BANK_CODE_MAP = Object.freeze({
  "bni":"bni","bank negara indonesia":"bni",
  "bri":"bri","bank rakyat indonesia":"bri",
  "bca":"bca","bank central asia":"bca",
  "mandiri":"mandiri","bank mandiri":"mandiri",
  "cimb":"cimb","cimb niaga":"cimb",
  "bsi":"bsi","bank syariah indonesia":"bsi",
  "dana":"dana", "ovo":"ovo", "gopay":"gopay",
  "btn":"btn","bjb":"bjb","permata":"permata","maybank":"maybank"
});

function normName(s) {
  if (!s) return "";
  return s.toString()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-zA-Z0-9\s]/g," ")
    .replace(/\s+/g," ")
    .trim()
    .toUpperCase();
}
function levenshtein(a,b){
  a=a||""; b=b||"";
  const m=a.length,n=b.length;
  const dp=Array.from({length:m+1},()=>new Array(n+1).fill(0));
  for(let i=0;i<=m;i++) dp[i][0]=i;
  for(let j=0;j<=n;j++) dp[0][j]=j;
  for(let i=1;i<=m;i++){
    for(let j=1;j<=n;j++){
      const cost=a[i-1]===b[j-1]?0:1;
      dp[i][j]=Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+cost);
    }
  }
  return dp[m][n];
}
function similarityRatio(a,b){
  a=normName(a); b=normName(b);
  if(!a && !b) return 1;
  const d=levenshtein(a,b);
  const maxLen=Math.max(a.length,b.length)||1;
  return +(1 - d/maxLen).toFixed(4);
}

async function cekRekening(bank_code, account_number){
  const controller = new AbortController();
  const timer = setTimeout(()=>controller.abort(), TIMEOUT_MS);
  try{
    const resp = await fetchFn("https://atlantich2h.com/transfer/cek_rekening", {
      method:"POST",
      headers:{ "Content-Type":"application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        api_key: API_KEY,
        bank_code,
        account_number
      }),
      signal: controller.signal
    });
    const text = await resp.text();
    let data;
    try{ data = JSON.parse(text); } catch{ data = { status:false, raw:text }; }
    return { http_status: resp.status, ok: resp.ok, payload: data };
  }catch(e){
    return { http_status: 0, ok:false, payload:{ status:false, error:e.message } };
  }finally{
    clearTimeout(timer);
  }
}

function detectBankCode(bankRaw){
  const key = (bankRaw||"").toString().trim().toLowerCase();
  return BANK_CODE_MAP[key] || key;
}

async function processRows(rows, mode){
  const out = [];
  for (let i=0;i<rows.length;i++){
    const row = rows[i];
    const bankRaw = (row.bank || row.bank_name || row["nama bank"] || row["bank_code"] || "").toString().trim();
    const acc = (row.account_number || row.norek || row["no rekening"] || row["nomor rekening"] || "").toString().trim();
    const expected = (row.name || row.nama || row["nama orang"] || row["nama lengkap"] || "").toString().trim();

    const bank_code = detectBankCode(bankRaw);
    if (!bank_code || !acc || (mode==="validate" && !expected)){
      out.push({
        bank: bankRaw, bank_code, account_number: acc,
        expected_name: mode==="validate" ? expected : undefined,
        api_name: "", api_status: "",
        valid_exact: mode==="validate" ? false : undefined,
        similarity: mode==="validate" ? 0 : undefined,
        note: "kolom tidak lengkap"
      });
      continue;
    }

    const r = await cekRekening(bank_code, acc);
    const apiName = r?.payload?.data?.nama_pemilik || "";
    const apiStat = r?.payload?.data?.status || (r?.payload?.status===true ? "valid" : "invalid");

    if (mode==="validate"){
      const eq = normName(expected) === normName(apiName);
      const sim = similarityRatio(expected, apiName);
      out.push({
        bank: bankRaw, bank_code, account_number: acc,
        expected_name: expected, api_name: apiName, api_status: apiStat,
        valid_exact: eq, similarity: sim,
        note: r.ok ? "" : (r.payload?.error || `HTTP ${r.http_status}`)
      });
    } else {
      // lookup only
      out.push({
        bank: bankRaw, bank_code, account_number: acc,
        api_name: apiName, api_status: apiStat,
        note: r.ok ? "" : (r.payload?.error || `HTTP ${r.http_status}`)
      });
    }

    if (RATE_DELAY_MS > 0){
      await new Promise(rs => setTimeout(rs, RATE_DELAY_MS));
    }
  }
  return out;
}

// ---- UI ----
app.get("/", (req,res)=>res.redirect("/ui"));
app.get("/ui", (req, res) => {
  res.type("html").send(`<!doctype html><html lang="id"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Bulk Cek Rekening — Lookup/Validate</title>
  <style>
    body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;max-width:900px;margin:36px auto;padding:0 16px}
    .card{padding:16px;border:1px solid #e5e7eb;border-radius:12px}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{border:1px solid #f1f5f9;padding:8px;text-align:left}
    .ok{color:#16a34a;font-weight:700}.bad{color:#ef4444;font-weight:700}
    .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    code{background:#f4f4f5;padding:2px 6px;border-radius:6px}
  </style></head><body>
    <h1>Bulk Cek Rekening</h1>
    <div class="card">
      <form id="f" enctype="multipart/form-data">
        <div class="row">
          <label><input type="radio" name="mode" value="lookup" checked> Cek Masal (lookup)</label>
          <label><input type="radio" name="mode" value="validate"> Validasi Nama (lookup + compare nama)</label>
        </div>
        <p style="margin:.5rem 0 0">Template:
          <a href="/template?mode=lookup">CSV lookup</a> •
          <a href="/template?mode=validate">CSV validate</a>
        </p>
        <p style="margin:.5rem 0">Upload CSV (
          lookup: kolom <code>bank,account_number</code> •
          validate: kolom <code>bank,account_number,name</code>)</p>
        <input type="file" name="file" accept=".csv" required>
        <div class="row" style="margin-top:8px">
          <button id="btn">Upload &amp; Proses</button>
          <a id="dl" href="#" style="display:none">Download CSV Hasil</a>
        </div>
      </form>
    </div>

    <div id="summary" style="margin:12px 0"></div>

    <table id="t" style="display:none">
      <thead id="thead"></thead>
      <tbody id="tbody"></tbody>
    </table>

    <script>
      const f = document.getElementById('f');
      const btn = document.getElementById('btn');
      const dl = document.getElementById('dl');
      const summary = document.getElementById('summary');
      const t = document.getElementById('t');
      const thead = document.getElementById('thead');
      const tbody = document.getElementById('tbody');

      function renderTable(mode, rows){
        t.style.display = '';
        tbody.innerHTML = '';
        if (mode === 'validate'){
          thead.innerHTML = '<tr><th>Bank</th><th>Bank Code</th><th>No Rek</th><th>Nama Diharapkan</th><th>Nama API</th><th>Status API</th><th>Valid (Exact)</th><th>Similarity</th><th>Catatan</th></tr>';
          rows.forEach(x=>{
            const tr = document.createElement('tr');
            tr.innerHTML = \`<td>\${x.bank}</td><td>\${x.bank_code}</td><td>\${x.account_number}</td><td>\${x.expected_name||""}</td><td>\${x.api_name||""}</td><td>\${x.api_status||""}</td><td class="\${x.valid_exact?'ok':'bad'}">\${x.valid_exact}</td><td>\${((x.similarity||0)*100).toFixed(1)}%</td><td>\${x.note||""}</td>\`;
            tbody.appendChild(tr);
          });
        } else {
          thead.innerHTML = '<tr><th>Bank</th><th>Bank Code</th><th>No Rek</th><th>Nama API</th><th>Status API</th><th>Catatan</th></tr>';
          rows.forEach(x=>{
            const tr = document.createElement('tr');
            tr.innerHTML = \`<td>\${x.bank}</td><td>\${x.bank_code}</td><td>\${x.account_number}</td><td>\${x.api_name||""}</td><td>\${x.api_status||""}</td><td>\${x.note||""}</td>\`;
            tbody.appendChild(tr);
          });
        }
      }

      async function downloadCSV(fd, mode){
        const r = await fetch('/bulk-'+mode+'?format=csv', { method:'POST', body:fd });
        const blob = await r.blob();
        const url = URL.createObjectURL(blob);
        dl.href = url; dl.download = 'hasil-'+mode+'.csv'; dl.style.display='inline-block'; dl.textContent='Download CSV Hasil';
      }

      f.addEventListener('submit', async (e)=>{
        e.preventDefault();
        dl.style.display='none';
        t.style.display='none';
        summary.textContent = 'Memproses...';
        btn.disabled = true;

        const fd = new FormData(f);
        const mode = new FormData(f).get('mode') || 'lookup';
        const r = await fetch('/bulk-'+mode+'?format=json', { method:'POST', body: fd });
        const j = await r.json();
        summary.textContent = \`Mode: \${mode} — Total: \${j.total}, OK: \${j.ok}, Fail: \${j.fail}\`;
        renderTable(mode, j.results);
        await downloadCSV(fd, mode);
        btn.disabled = false;
      });
    </script>
  </body></html>`);
});

// ---- API ----
app.get("/health", (req,res)=>res.json({ ok:true, time:new Date().toISOString() }));

app.get("/template", (req,res)=>{
  const mode = (req.query.mode||"lookup").toString();
  let csv;
  if (mode === "validate"){
    csv = "bank,account_number,name\nBNI,1967308123,CONTOH NAMA\nBCA,1234567890,CONTOH NAMA 2\n";
  } else {
    csv = "bank,account_number\nBNI,1967308123\nBCA,1234567890\n";
  }
  res.setHeader("Content-Type","text/csv; charset=utf-8");
  res.setHeader("Content-Disposition",`attachment; filename=template-${mode}.csv`);
  res.send(csv);
});

// Bulk lookup only
app.post("/bulk-lookup", upload.single("file"), async (req,res)=>{
  if (!API_KEY) return res.status(500).json({ status:false, error:"ATLANTIC_API_KEY belum di-set" });
  if (!req.file) return res.status(400).json({ status:false, error:"Upload file CSV di field 'file'" });
  const text = req.file.buffer.toString("utf8");
  const parsed = Papa.parse(text, { header:true, skipEmptyLines:true });
  const rows = parsed.data || [];
  const results = await processRows(rows, "lookup");
  const summary = {
    status:true, total: results.length,
    ok: results.filter(x=> (x.api_status||'').toLowerCase()==='valid').length,
    fail: results.filter(x=> (x.api_status||'').toLowerCase()!=='valid').length,
    results
  };
  const fmt = (req.query.format||"json").toString().toLowerCase();
  if (fmt === "csv"){
    const csv = Papa.unparse(results, { columns:["bank","bank_code","account_number","api_name","api_status","note"] });
    res.setHeader("Content-Type","text/csv; charset=utf-8");
    res.setHeader("Content-Disposition","attachment; filename=hasil-lookup.csv");
    return res.send(csv);
  }
  res.json(summary);
});

// Bulk validate (with expected name)
app.post("/bulk-validate", upload.single("file"), async (req,res)=>{
  if (!API_KEY) return res.status(500).json({ status:false, error:"ATLANTIC_API_KEY belum di-set" });
  if (!req.file) return res.status(400).json({ status:false, error:"Upload file CSV di field 'file'" });
  const text = req.file.buffer.toString("utf8");
  const parsed = Papa.parse(text, { header:true, skipEmptyLines:true });
  const rows = parsed.data || [];
  const results = await processRows(rows, "validate");
  const summary = {
    status:true, total: results.length,
    ok: results.filter(x=> x.valid_exact === true).length,
    fail: results.filter(x=> x.valid_exact !== true).length,
    results
  };
  const fmt = (req.query.format||"json").toString().toLowerCase();
  if (fmt === "csv"){
    const csv = Papa.unparse(results, { columns:["bank","bank_code","account_number","expected_name","api_name","api_status","valid_exact","similarity","note"] });
    res.setHeader("Content-Type","text/csv; charset=utf-8");
    res.setHeader("Content-Disposition","attachment; filename=hasil-validate.csv");
    return res.send(csv);
  }
  res.json(summary);
});

app.listen(PORT, ()=>{
  console.log("Ready on http://0.0.0.0:"+PORT);
});
