# Atlantic Pedia — Cek Rekening (Node.js Proxy API)

Proxy API ini memungkinkan cek rekening Atlantic Pedia dipanggil **langsung dari browser/URL** tanpa terkena CORS dan **tanpa mengekspos API key** di frontend.

## Jalankan secara lokal (Node 18+)
```bash
cp .env.example .env
# edit .env -> ATLANTIC_API_KEY=...

npm install
npm start
```
Akses:
- Healthcheck: `http://localhost:3000/health`
- Tes cepat di browser: `http://localhost:3000/?` (form sederhana)
- Endpoint API:
  - GET: `http://localhost:3000/cek-rekening?bank_code=bni&account_number=0123456789`
  - POST: `http://localhost:3000/cek-rekening` (body x-www-form-urlencoded/json)

## Docker (Portainer/Compose)
Siapkan file `.env` di folder yang sama:
```
ATLANTIC_API_KEY=REPLACE_WITH_YOUR_KEY
```
Lalu:
```bash
docker compose up -d
```

## Catatan
- `ALLOW_ORIGIN=*` mengizinkan front-end manapun mengakses API ini. Ubah sesuai domain Anda untuk keamanan.
- Timeout request ke upstream diset 15 detik.
- API key dibaca dari environment `ATLANTIC_API_KEY`.
- Endpoint upstream: `https://atlantich2h.com/transfer/cek_rekening`.
