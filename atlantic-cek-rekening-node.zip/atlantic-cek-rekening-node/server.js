// Atlantic Pedia "cek rekening" proxy API
import express from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

// Use native fetch when available; fallback to node-fetch
let fetchFn = globalThis.fetch;
if (!fetchFn) {
  const mod = await import("node-fetch");
  fetchFn = mod.default;
}

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ATLANTIC_API_KEY;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || "*";

if (!API_KEY) {
  console.warn("[WARN] ATLANTIC_API_KEY is not set. Set it in .env file.");
}

app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: ALLOW_ORIGIN }));

app.get("/health", (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Accept both GET (query) and POST (body) to be convenient in browser
const handler = async (req, res) => {
  try {
    const bank_code = (req.method === "GET" ? req.query.bank_code : req.body.bank_code)?.toString().trim();
    const account_number = (req.method === "GET" ? req.query.account_number : req.body.account_number)?.toString().trim();

    if (!bank_code || !account_number) {
      return res.status(400).json({
        status: false,
        error: "bank_code dan account_number wajib diisi",
        example: "/cek-rekening?bank_code=bni&account_number=0123456789"
      });
    }
    if (!API_KEY) {
      return res.status(500).json({ status: false, error: "Server belum dikonfigurasi (ATLANTIC_API_KEY kosong)" });
    }

    // Call upstream API
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000); // 15s timeout

    const upstream = await fetchFn("https://atlantich2h.com/transfer/cek_rekening", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        api_key: API_KEY,
        bank_code,
        account_number
      }),
      signal: controller.signal
    }).catch(err => {
      throw new Error("Upstream fetch error: " + err.message);
    });
    clearTimeout(timeout);

    const text = await upstream.text();
    // Try parse JSON; if fail, return as raw
    let data;
    try { data = JSON.parse(text); } catch { data = { status: false, raw: text }; }

    // Normalize a bit: attach input echo
    const out = {
      status: data?.status === true,
      data: data?.data || null,
      input: { bank_code, account_number },
      upstream_status: upstream.status,
      upstream_ok: upstream.ok
    };
    // include original payload for debugging
    if (data && typeof data === "object") out.upstream = data;

    res.setHeader("Cache-Control", "no-store");
    res.json(out);
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
};

app.get("/cek-rekening", handler);
app.post("/cek-rekening", handler);

// Simple index page for manual test in browser
app.get("/", (req, res) => {
  res.type("html").send(`<!doctype html>
  <html lang="id"><head><meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Cek Rekening API Proxy</title>
  <style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;max-width:720px;margin:40px auto;padding:0 16px}
  code{background:#f4f4f5;padding:2px 6px;border-radius:6px} input{padding:10px;border-radius:8px;border:1px solid #ccc;margin-right:6px}
  button{padding:10px 14px;border-radius:8px;border:0;background:#16a34a;color:#fff;font-weight:700}
  pre{background:#0b1220;color:#e5e7eb;padding:12px;border-radius:10px;overflow:auto}
  </style></head><body>
    <h1>Cek Rekening — Proxy API</h1>
    <p>Kirim GET dari browser: <code>/cek-rekening?bank_code=bni&account_number=0123456789</code></p>
    <form id="f"><input id="bank" placeholder="bank_code (mis. bni)" required />
    <input id="acc" placeholder="account_number" required /><button>Cek</button></form>
    <pre id="out">Menunggu...</pre>
    <script>
      f.addEventListener("submit", async (e)=>{
        e.preventDefault();
        out.textContent = "Memeriksa...";
        const url = \`/cek-rekening?bank_code=\${encodeURIComponent(bank.value)}&account_number=\${encodeURIComponent(acc.value)}\`;
        const r = await fetch(url);
        out.textContent = await r.text();
      });
    </script>
  </body></html>`);
});

app.listen(PORT, () => {
  console.log(`Server listening on http://0.0.0.0:${PORT}`);
});
